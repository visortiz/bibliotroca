</div>

<footer id="footer">
	<p>Página carregada em <strong>{elapsed_time}</strong> segundos. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Versão <strong>' . CI_VERSION . '</strong>' : '' ?></p>
</footer>

</body>
</html>