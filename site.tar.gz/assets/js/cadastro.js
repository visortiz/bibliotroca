$(function(){
	$.validate({lang: 'pt'});

	//CADASTRO
	$("#enviar_cadastro").click(function(){
		$("#form_cadastro").submit();
	});



});
